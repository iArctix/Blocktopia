﻿using UnityEngine;
using Boxophobic.StyledGUI;

public class StyledScriptableObject: ScriptableObject
{

}
