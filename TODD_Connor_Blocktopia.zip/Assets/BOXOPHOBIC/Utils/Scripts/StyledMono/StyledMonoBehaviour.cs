﻿using UnityEngine;
using Boxophobic.StyledGUI;

public class StyledMonoBehaviour : MonoBehaviour
{

}
