using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class OreInstance : MonoBehaviour
{
    public OreData oreData;
   
    

    void Update()
    {
      
    }
}