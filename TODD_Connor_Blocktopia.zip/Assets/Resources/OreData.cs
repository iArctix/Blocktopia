using UnityEngine;

[CreateAssetMenu(fileName = "New Ore", menuName = "Ore")]
public class OreData : ScriptableObject
{
    public int toollevelrequirement;
    public string Resourcename;
    

}