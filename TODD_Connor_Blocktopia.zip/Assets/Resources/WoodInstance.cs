using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WoodInstance : MonoBehaviour
{
    public WoodData woodData;

    void Start()
    {
 
    }
}